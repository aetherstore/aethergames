const chalk = require("chalk")
const fs = require("fs")

  global.ownerNumber = "6283873357108@s.whatsapp.net"
  global.kontakOwner = "6283873357108"
  global.namaStore = "Aether Store"
  global.botName = "Bot Aether Store"
  global.ownerName = "Anam"
  
  
  global.linkyt = "Gada channel yt follow ig aja🗿"
  global.linkig = "Ig Store : @aethertopup | Ig Pribadi : @anammm_200"
  global.dana = "Scan qris di atas"
  global.sawer = "Scan qris di atas"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})